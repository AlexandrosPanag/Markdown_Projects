<head>
<link href="https://raw.githubusercontent.com/AlexandrosPanag/AlexandrosPanag.github.io/main/favicon.ico" rel="icon" type="image/x-icon" />
</head>





[![GitHub](https://img.shields.io/badge/GitHub-%40alexandrospanag-239a3b.svg)](https://github.com/alexandrospanag)
[![LinkedIn](https://img.shields.io/badge/Linked-in-0c66c3.svg)](https://www.linkedin.com/in/αλέξανδρος-παναγιωτακόπουλος/)


<img src="https://komarev.com/ghpvc/?username=AlexandrosPanag01&label=Profile%20views&color=129e00&style=plastic" alt="AlexandrosPanag" /> 


```Hello friend, welcome to my page!``` 


```---> 04/04/2022 : NEW: Started My Intership !!! <---```

```---> 06/08/2022 : NEW :  New page look <---```

```---> 15/06/2022 : NEW :  Python Repository updates and more programs <---```

```---> 20/06/2022 : NEW :  Upcoming ESP32 Projects <---```

```---> 01/07/2022 : NEW :  Upcoming MicroPython projects <---```

<img align="left" alt="Coding" width="50" src="https://media1.giphy.com/avatars/Outcrowd/stpvc1zlUiXd.gif">

[![](https://raw.githubusercontent.com/AlexandrosPanag/AlexandrosPanag.github.io/main/Banner.gif)](https://github.com/AlexandrosPanag?tab=repositories)


[<img align="center" alt="GITHUB" width="35x" src="https://raw.githubusercontent.com/devicons/devicon/1119b9f84c0290e0f0b38982099a2bd027a48bf1/icons/github/github-original.svg" />][github]
[<img align="center" alt="LINKEDIN | LinkedIn" width="35px" src="https://raw.githubusercontent.com/devicons/devicon/1119b9f84c0290e0f0b38982099a2bd027a48bf1/icons/linkedin/linkedin-original.svg" />][linkedin]




[github]: https://github.com/AlexandrosPanag
[linkedin]: https://www.linkedin.com/in/αλέξανδρος-παναγιωτακόπουλος/



-----------------
<h3 align="center">🎓 2018: Graduated from Art School of Heraklion, Crete</h3>
-----------------


-----------------
<h3 align="center">🎓 NOW: Student at University of Ioannina - Department of Inforormatics & Telecommunications.</h3>
-----------------






[![My GitHub Stats](https://github-readme-stats.vercel.app/api/?username=alexandrospanag&count_private=true&theme=darcula&showicons=true)]()



[![GitHub Streak](https://github-readme-streak-stats.herokuapp.com?user=AlexandrosPanag&theme=dark)](https://git.io/streak-stats)



[![GitHub activity graph](https://activity-graph.herokuapp.com/graph?username=AlexandrosPanag&&theme=xcode)](https://github.com/AlexandrosPanag)






<br/>






---




<img align="left" alt="Coding" width="30" src="https://i.giphy.com/media/jSKBmKkvo2dPQQtsR1/giphy.webp">   

<h3 align="left">Languages and Tools:</h3>
<p align="left"> <a href="https://www.arduino.cc/" target="_blank" rel="noreferrer"> <img src="https://cdn.worldvectorlogo.com/logos/arduino-1.svg" alt="arduino" width="40" height="40"/> </a> <a href="https://www.cprogramming.com/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/c/c-original.svg" alt="c" width="40" height="40"/> </a> <a href="https://isocpp.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/cplusplus/cplusplus-original.svg" alt="cplusplus" width="40" height="40"/> </a> <a href="https://www.java.com" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/java/java-original.svg" alt="java" width="40" height="40"/> </a><a href="https://www.mathworks.com/" target="_blank" rel="noreferrer"> <img src="https://upload.wikimedia.org/wikipedia/commons/2/21/Matlab_Logo.png" alt="matlab" width="40" height="40"/></a> <a href="https://www.latex-project.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/1119b9f84c0290e0f0b38982099a2bd027a48bf1/icons/latex/latex-original.svg" alt="LaTeX" width="40" height="40"/> </a><a href="https://www.mysql.com/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original-wordmark.svg" alt="mysql" width="40" height="40"/> </a><a href="https://www.markdownguide.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/1119b9f84c0290e0f0b38982099a2bd027a48bf1/icons/markdown/markdown-original.svg" alt="mysql" width="40" height="40"/> </a><a href="https://processing.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/1119b9f84c0290e0f0b38982099a2bd027a48bf1/icons/processing/processing-original-wordmark.svg" alt="processing" width="40" height="40"/> </a><a href="https://developer.android.com/studio?gclid=CjwKCAjwkYGVBhArEiwA4sZLuGMfkWV1fXBUX9AlXBdqH7gltOb-0p3XS0aPC0h3trRRsnGWn0i_4BoCwuAQAvD_BwE&gclsrc=aw.ds" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/1119b9f84c0290e0f0b38982099a2bd027a48bf1/icons/androidstudio/androidstudio-original.svg" alt="androidstudio" width="40" height="40"/> </a><a href="https://www.python.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a> </p>
 
 
 




<br/>
 




<img align="left" alt="Coding" width="30" src="https://i.giphy.com/media/iDaCeaKrHhUI1I8e2b/giphy.webp"> 
 

 <h3 align="left">A few more skills:</h3>


 
 
 
PC Building, MS Office, SystemVerilog , Windows , ESP32, NodeMcu Lua CH340G ESP8266 WIFI, MicroPython , VHDL , Prolog , Wiring C , MSP430 & MIPS Assembly









<!-- BLOG-POST-LIST:START -->

 
 

## <img align="left" alt="Coding" width="30" src="https://media2.giphy.com/media/LYBMuRwH3JkhdmLbGE/giphy.gif?cid=ecf05e47jx65wsoe0706u8m33zcjgdboduv6popqnf3h902n&rid=giphy.gif&ct=s">  

 <h3 align="left">My Projects </h3>
<!-- BLOG-POST-LIST:START -->

 
 
- [My Arduino Projects](https://github.com/AlexandrosPanag/My_Arduino_Projects)
- [My Processing Projects](https://github.com/AlexandrosPanag/My_Processing_Projects)
- [My MicroPython Projects](https://github.com/AlexandrosPanag/My_MicroPython_Projects)
- [My ESP32 Projects](https://github.com/AlexandrosPanag/My_ESP32_Projects)
- [My ESP8266 Projects](https://github.com/AlexandrosPanag/My_esp8266_Projects)
- [My Python Projects](https://github.com/AlexandrosPanag/My_Python_Projects)
- [My Markdown Projects](https://github.com/AlexandrosPanag/My_Markdown_Projects)
- [My Prolog Projects](https://github.com/AlexandrosPanag/My_Prolog_Projects)
- [My MSP430F5529 Projects](https://github.com/AlexandrosPanag/Ti-launch-pad-with-MSP430-MCU)
- [My C Projects](https://github.com/AlexandrosPanag/My-C-Projects)
- [My MIPS Assembly Projects](https://github.com/AlexandrosPanag/My-MIPS-Assembly-Projects)
- [My Java Projects](https://github.com/AlexandrosPanag/My-Java-Projects)
- [My C++ Projects](https://github.com/AlexandrosPanag/My_CPlusPlus_Projects)
- [My SQL Projects](https://github.com/AlexandrosPanag/My_SQL_Projects)
- [My OCTAVE / MATLAB Projects](https://github.com/AlexandrosPanag/My_Octave_Projects)
- [My VHDL Projects](https://github.com/AlexandrosPanag/My_VHDL_Projects)
- [My SystemVerilog Projects](https://github.com/AlexandrosPanag/My_System_Verilog_Projects)
- [My Android Studio Projects](https://github.com/AlexandrosPanag/My_Android_Studio_Projects)
- [My Ruby Projects! (coming soon...)]()
 
 
<!-- BLOG-POST-LIST:END -->


---


[GITHUB]:https://github.com/AlexandrosPanag


###### Copyright © 2021-2022 AlexandrosPanag







